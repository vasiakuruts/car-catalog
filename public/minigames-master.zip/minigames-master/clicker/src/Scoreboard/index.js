export { default } from './Scoreboard';
