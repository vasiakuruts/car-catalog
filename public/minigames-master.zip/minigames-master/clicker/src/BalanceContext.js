import React from 'react';

const BalanceContext = React.createContext(null);

export default BalanceContext;
